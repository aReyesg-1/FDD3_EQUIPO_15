// ==========================================================================
// 1. OBTENER DATOS DEL USUARIO LOGUEADO
// ==========================================================================
const emailActivo = localStorage.getItem('usuarioActivo');
const datosUsuarioRaw = localStorage.getItem(emailActivo);

if (datosUsuarioRaw) {
    const datosUsuario = JSON.parse(datosUsuarioRaw);
    
    // Mostramos el nombre (lo que está antes del @gmail.com)
    const nombreUsuario = datosUsuario.gmail.split('@')[0];
    const userDisplay = document.getElementById('user-display');
    if (userDisplay) userDisplay.textContent = nombreUsuario;
    
    // Mostramos el código del compost que registró
    const compostDisplay = document.getElementById('compost-id-display');
    if (compostDisplay) compostDisplay.textContent = `Código: ${datosUsuario.codigo_compost}`;
}

// ==========================================================================
// 2. CONTROL DEL BOTÓN CERRAR SESIÓN (CORREGIDO Y LIMPIO)
// ==========================================================================
const logoutBtn = document.getElementById('logout-btn');
if (logoutBtn) {
    logoutBtn.addEventListener('click', (e) => {
        e.preventDefault();
        localStorage.removeItem('usuarioActivo'); // Elimina la sesión de la memoria
        window.location.href = "index.html";     // Redirige al login de inmediato
    });
}

// ==========================================================================
// 3. RENDERIZAR GRÁFICO (Chart.js)
// ==========================================================================
const chartCanvas = document.getElementById('compostChart');

if (chartCanvas) {
    const ctx = chartCanvas.getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['14/05', '15/05', '16/05', '17/05', '18/05', '19/05', '20/05'],
            datasets: [
                {
                    label: 'Temperatura (°C)',
                    data: [52, 54, 55, 53, 56, 55, 55],
                    borderColor: '#e53e3e',
                    backgroundColor: 'transparent',
                    borderWidth: 2
                },
                {
                    label: 'Humedad (%)',
                    data: [55, 56, 58, 57, 59, 58, 58],
                    borderColor: '#3182ce',
                    backgroundColor: 'transparent',
                    borderWidth: 2
                }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { position: 'top' }
            }
        }
    });
}