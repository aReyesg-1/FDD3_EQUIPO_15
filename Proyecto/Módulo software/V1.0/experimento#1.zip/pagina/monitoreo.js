// ==========================================================================
// 1. OBTENER DATOS DEL USUARIO LOGUEADO
// ==========================================================================
const emailActivo = localStorage.getItem('usuarioActivo');
const datosUsuarioRaw = localStorage.getItem(emailActivo);

if (datosUsuarioRaw) {
    const datosUsuario = JSON.parse(datosUsuarioRaw);
    const compostDisplay = document.getElementById('compost-id-display');
    if (compostDisplay) compostDisplay.textContent = `Código: ${datosUsuario.codigo_compost}`;
}

// ==========================================================================
// 2. CONTROL DEL BOTÓN CERRAR SESIÓN
// ==========================================================================
const logoutBtn = document.getElementById('logout-btn');
if (logoutBtn) {
    logoutBtn.addEventListener('click', (e) => {
        e.preventDefault();
        localStorage.removeItem('usuarioActivo'); // Borra la sesión
        window.location.href = "index.html";     // Regresa al login/registro
    });
}

// ==========================================================================
// 3. RENDERIZAR GRÁFICOS DETALLADOS (Chart.js)
// ==========================================================================

// --- Gráfico 1: Clima ---
const ctxClima = document.getElementById('chartClimaDetalle');
if (ctxClima) {
    new Chart(ctxClima.getContext('2d'), {
        type: 'line',
        data: {
            labels: ['00:00', '04:00', '08:00', '12:00', '16:00', '20:00'],
            datasets: [
                { label: 'Temperatura °C', data: [48, 49, 52, 55, 54, 53], borderColor: '#e53e3e', backgroundColor: 'transparent', borderWidth: 2 },
                { label: 'Humedad %', data: [60, 60, 59, 58, 58, 59], borderColor: '#3182ce', backgroundColor: 'transparent', borderWidth: 2 }
            ]
        },
        options: { responsive: true }
    });
}

// --- Gráfico 2: Gases ---
const ctxGases = document.getElementById('chartGasesDetalle');
if (ctxGases) {
    new Chart(ctxGases.getContext('2d'), {
        type: 'bar',
        data: {
            labels: ['00:00', '04:00', '08:00', '12:00', '16:00', '20:00'],
            datasets: [
                { label: 'Metano MQ4 (ppm)', data: [120, 150, 190, 230, 210, 180], backgroundColor: 'rgba(113, 128, 150, 0.7)' },
                { label: 'CO2 MQ135 (ppm)', data: [310, 320, 340, 360, 350, 330], backgroundColor: 'rgba(27, 94, 32, 0.7)' }
            ]
        },
        options: { responsive: true }
    });
}