// ==========================================================================
// 1. OBTENER DATOS DEL USUARIO LOGUEADO
// ==========================================================================
const emailActivo = localStorage.getItem('usuarioActivo');
const datosUsuarioRaw = localStorage.getItem(emailActivo);

if (datosUsuarioRaw) {
    const datosUsuario = JSON.parse(datosUsuarioRaw);
    const compostDisplay = document.getElementById('compost-id-display');
    if (compostDisplay) compostDisplay.textContent = `Código: ${datosUsuario.codigo_compost}`;
}

// ==========================================================================
// 2. CONTROL DEL BOTÓN CERRAR SESIÓN
// ==========================================================================
const logoutBtn = document.getElementById('logout-btn');
if (logoutBtn) {
    logoutBtn.addEventListener('click', (e) => {
        e.preventDefault();
        localStorage.removeItem('usuarioActivo');
        window.location.href = "index.html"; 
    });
}

// ==========================================================================
// 3. LOGICA DEL FORMULARIO DE ACCIONES (INTERACTIVO)
// ==========================================================================
const actionForm = document.getElementById('action-form');
const logList = document.getElementById('log-list');

if (actionForm && logList) {
    actionForm.addEventListener('submit', (e) => {
        e.preventDefault();

        const type = document.getElementById('action-type').value;
        const notes = document.getElementById('action-notes').value;
        
        // Obtener la fecha y hora actual formateada de forma sencilla
        const ahora = new Date();
        const fechaFormateada = `${ahora.getDate()}/${ahora.getMonth() + 1} a las ${ahora.getHours()}:${ahora.getMinutes().toString().padStart(2, '0')}`;

        // Crear el nuevo elemento en la lista
        const nuevoItem = document.createElement('li');
        nuevoItem.innerHTML = `<strong>${type}:</strong> ${notes}<br><small style="color:#a0aec0;">Guardado: Hoy (${fechaFormateada})</small>`;
        
        // Insertarlo arriba en la lista de actividades
        logList.insertBefore(nuevoItem, logList.firstChild);

        // Limpiar el cuadro de texto de las notas
        document.getElementById('action-notes').value = "";
    });
}