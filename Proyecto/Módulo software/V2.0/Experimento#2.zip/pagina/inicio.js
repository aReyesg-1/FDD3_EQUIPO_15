// ==========================================================================
// 1. OBTENER DATOS DEL USUARIO LOGUEADO
// ==========================================================================
const emailActivo = localStorage.getItem('usuarioActivo');
const datosUsuarioRaw = localStorage.getItem(emailActivo);

if (datosUsuarioRaw) {
    const datosUsuario = JSON.parse(datosUsuarioRaw);
    
    // Mostramos el nombre (lo que está antes del @gmail.com)
    const nombreUsuario = datosUsuario.gmail.split('@')[0];
    const userDisplay = document.getElementById('user-display');
    if (userDisplay) userDisplay.textContent = nombreUsuario;
    
    // Mostramos el código del compost que registró
    const compostDisplay = document.getElementById('compost-id-display');
    if (compostDisplay) compostDisplay.textContent = `Código: ${datosUsuario.codigo_compost}`;
}

// ==========================================================================
// 2. CONTROL DEL BOTÓN CERRAR SESIÓN (CORREGIDO Y LIMPIO)
// ==========================================================================
const logoutBtn = document.getElementById('logout-btn');
if (logoutBtn) {
    logoutBtn.addEventListener('click', (e) => {
        e.preventDefault();
        localStorage.removeItem('usuarioActivo'); // Elimina la sesión de la memoria
        window.location.href = "index.html";     // Redirige al login de inmediato
    });
}

// ==========================================================================
// 3. RENDERIZAR GRÁFICO (Chart.js)
// ==========================================================================
const chartCanvas = document.getElementById('compostChart');

if (chartCanvas) {
    const ctx = chartCanvas.getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['14/05', '15/05', '16/05', '17/05', '18/05', '19/05', '20/05'],
            datasets: [
                {
                    label: 'Temperatura (°C)',
                    data: [52, 54, 55, 53, 56, 55, 55],
                    borderColor: '#e53e3e',
                    backgroundColor: 'transparent',
                    borderWidth: 2
                },
                {
                    label: 'Humedad (%)',
                    data: [55, 56, 58, 57, 59, 58, 58],
                    borderColor: '#3182ce',
                    backgroundColor: 'transparent',
                    borderWidth: 2
                }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { position: 'top' }
            }
        }
    });
}
// Cambia esto por la dirección IP que te muestre la pantalla LCD o el monitor serie del Arduino
const ARDUINO_IP = "http://10.46.168.228"; 

function consultarSensoresArduino() {
    // Hacemos la llamada HTTP asíncrona al módulo Wi-Fi
    fetch(`${ARDUINO_IP}/datos`)
        .then(response => response.json())
        .then(datos => {
            console.log("Datos recibidos del Compost:", datos);

            // 1. ACTUALIZAR LAS TARJETAS VISUALES EN PANTALLA
            document.querySelector('.em-verde .sensor-value').textContent = `${datos.temperatura} °C`;
            document.querySelector('.em-azul .sensor-value').textContent = `${datos.humedad} %`;
            document.querySelector('.em-negro .sensor-value').textContent = `${datos.mq4} <small>ppm</small>`;
            document.querySelector('.em-gris .sensor-value').textContent = `${datos.mq135} <small>ppm</small>`;


            // 2. REALIZAR OPERACIONES LÓGICAS CON LOS DATOS (Ejemplo: Cambiar Estado General)
            const badge = document.querySelector('.status-badge');
            const desc = document.querySelector('.status-desc');

            if (datos.temperatura > 65 || promedioGases > 500) {
                badge.textContent = "⚠️ Alerta";
                badge.style.backgroundColor = "#e53e3e";
                desc.textContent = "¡Condiciones críticas! Requiere volteo o enfriamiento.";
            } else if (datos.temperatura >= 45 && datos.temperatura <= 65) {
                badge.textContent = "😊 Óptimo";
                badge.style.backgroundColor = "#38a169";
                desc.textContent = "¡Excelente! Tu compost está en fase termófila de higienización.";
            } else {
                badge.textContent = "⏳ Estable";
                badge.style.backgroundColor = "#3182ce";
                desc.textContent = "El compost está estable, pero registra temperaturas bajas.";
            }
        })
        .catch(error => console.error("Error conectando con los sensores Wi-Fi:", error));
}

// Ejecutar la primera consulta al cargar la página
consultarSensoresArduino();

// Programar el temporizador cíclico para actualizar de forma invisible cada 10 segundos
setInterval(consultarSensoresArduino, 5000);