// ==========================================================================
// 1. OBTENER DATOS DEL USUARIO LOGUEADO
// ==========================================================================
const emailActivo = localStorage.getItem('usuarioActivo');
const datosUsuarioRaw = localStorage.getItem(emailActivo);

if (datosUsuarioRaw) {
    const datosUsuario = JSON.parse(datosUsuarioRaw);
    const compostDisplay = document.getElementById('compost-id-display');
    if (compostDisplay) compostDisplay.textContent = `Código: ${datosUsuario.codigo_compost}`;
}

// ==========================================================================
// 2. CONTROL DEL BOTÓN CERRAR SESIÓN
// ==========================================================================
const logoutBtn = document.getElementById('logout-btn');
if (logoutBtn) {
    logoutBtn.addEventListener('click', (e) => {
        e.preventDefault();
        localStorage.removeItem('usuarioActivo');
        window.location.href = "index.html"; 
    });
}


const ARDUINO_IP = "http://10.46.168.228"; 