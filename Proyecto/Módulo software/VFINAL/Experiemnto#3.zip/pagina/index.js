// Selección de elementos del DOM
const toggleLink = document.getElementById('toggle-link');
const toggleMessage = document.getElementById('toggle-message');
const authTitle = document.getElementById('auth-title');
const authSubtitle = document.getElementById('auth-subtitle');
const compostGroup = document.getElementById('compost-group');
const compostInput = document.getElementById('codigo_compost');
const submitBtn = document.getElementById('submit-btn');
const authForm = document.getElementById('auth-form');
const alertMessage = document.getElementById('alert-message');

let modoRegistro = false;

// ==========================================================================
// 1. VERIFICAR SI YA HAY UNA SESIÓN ACTIVA AL CARGAR LA PÁGINA
// ==========================================================================
if (localStorage.getItem('usuarioActivo')) {
    // Si ya inició sesión antes, se salta esta pantalla y va directo al inicio
    window.location.href = "inicio.html"; }

// ==========================================================================
// 2. ALTERNAR LA INTERFAZ ENTRE INICIAR SESIÓN Y REGISTRARSE
// ==========================================================================
toggleLink.addEventListener('click', (e) => {
    e.preventDefault();
    modoRegistro = !modoRegistro;
    alertMessage.classList.add('hidden'); // Ocultar alertas anteriores

    if (modoRegistro) {
        authTitle.textContent = "Crear Cuenta";
        authSubtitle.textContent = "Regístrate para enlazar tu dispositivo";
        compostGroup.classList.remove('hidden');
        compostInput.required = true;
        submitBtn.textContent = "Registrarse";
        toggleMessage.textContent = "¿Ya tienes una cuenta?";
        toggleLink.textContent = "Inicia sesión aquí";
    } else {
        authTitle.textContent = "Iniciar Sesión";
        authSubtitle.textContent = "Ingresa a tu sistema de monitoreo inteligente";
        compostGroup.classList.add('hidden');
        compostInput.required = false;
        submitBtn.textContent = "Ingresar";
        toggleMessage.textContent = "¿No tienes una cuenta?";
        toggleLink.textContent = "Regístrate aquí";
    }
});

// ==========================================================================
// 3. EVENTO AL ENVIAR EL FORMULARIO (BOTÓN INGRESAR / REGISTRARSE)
// ==========================================================================
authForm.addEventListener('submit', (e) => {
    e.preventDefault(); // Evita que la página se recargue por defecto

    const gmail = document.getElementById('gmail').value;
    const password = document.getElementById('password').value;
    const codigoCompost = compostInput.value;

    if (modoRegistro) {
        // --- PROCESO DE REGISTRO ---
        const nuevoUsuario = {
            gmail: gmail,
            password: password,
            codigo_compost: codigoCompost
        };
        
        // Guardamos el usuario usando su correo como identificador único
        localStorage.setItem(gmail, JSON.stringify(nuevoUsuario));
        
        // Iniciamos la sesión marcándolo como el usuario activo
        localStorage.setItem('usuarioActivo', gmail);

        mostrarAlerta("¡Cuenta registrada con éxito! Redirigiendo...", "success");
        
        // Espera 1.5 segundos mostrando el mensaje de éxito antes de cambiar de página
        setTimeout(() => { 
            window.location.href = "inicio.html"; 
        }, 1500);

    } else {
        // --- PROCESO DE INICIO DE SESIÓN ---
        const usuarioGuardado = localStorage.getItem(gmail);

        if (usuarioGuardado) {
            const datosUsuario = JSON.parse(usuarioGuardado);

            // Validar si la contraseña coincide con la registrada localmente
            if (datosUsuario.password === password) {
                // Guardamos el inicio de sesión exitoso
                localStorage.setItem('usuarioActivo', gmail);
                
                mostrarAlerta("Inicio de sesión correcto. Cargando panel...", "success");
                
                // Redirigir a la página de inicio
                setTimeout(() => { 
                    window.location.href = "inicio.html"; 
                }, 1500);
            } else {
                mostrarAlerta("Contraseña incorrecta.", "error");
            }
        } else {
            mostrarAlerta("Este correo electrónico no está registrado.", "error");
        }
    }
});

// Función auxiliar para pintar las alertas de éxito o error en pantalla
function mostrarAlerta(mensaje, tipo) {
    alertMessage.className = `alert ${tipo}`;
    alertMessage.textContent = mensaje;
    alertMessage.classList.remove('hidden');
}