// ==========================================================================
// 1. OBTENER DATOS DEL USUARIO LOGUEADO
// ==========================================================================
const emailActivo = localStorage.getItem('usuarioActivo');
const datosUsuarioRaw = localStorage.getItem(emailActivo);

if (datosUsuarioRaw) {
    const datosUsuario = JSON.parse(datosUsuarioRaw);
    
    // Mostramos el nombre (lo que está antes del @gmail.com)
    const nombreUsuario = datosUsuario.gmail.split('@')[0];
    const userDisplay = document.getElementById('user-display');
    if (userDisplay) userDisplay.textContent = nombreUsuario;
    
    // Mostramos el código del compost que registró
    const compostDisplay = document.getElementById('compost-id-display');
    if (compostDisplay) compostDisplay.textContent = `Código: ${datosUsuario.codigo_compost}`;
}

// ==========================================================================
// 2. CONTROL DEL BOTÓN CERRAR SESIÓN (CORREGIDO Y LIMPIO)
// ==========================================================================
const logoutBtn = document.getElementById('logout-btn');
if (logoutBtn) {
    logoutBtn.addEventListener('click', (e) => {
        e.preventDefault();
        localStorage.removeItem('usuarioActivo'); // Elimina la sesión de la memoria
        window.location.href = "index.html";     // Redirige al login de inmediato
    });
}
// Cambia esto por la dirección IP que te muestre la pantalla LCD o el monitor serie del Arduino
const ARDUINO_IP = "http://10.46.168.228"; 

function consultarSensoresArduino() {
    const txtStatus = document.getElementById('status-text');
    const badge = document.getElementById('main-badge');
    const desc = document.getElementById('main-desc');

    fetch(`${ARDUINO_IP}/datos`)
        .then(response => {
            if (!response.ok) throw new Error("Error de red");
            return response.json();
        })
        .then(datos => {
            console.log("Datos en inicio:", datos);

            // 1. CONTROL DEL INDICADOR WI-FI EN LA BARRA LATERAL
            if (txtStatus) {
                txtStatus.textContent = "Conectado";
                txtStatus.style.color = "#38a169";
            }

            // 2. ACTUALIZAR LAS TARJETAS VISUALES EN PANTALLA
            document.querySelector('.em-verde .sensor-value').textContent = `${datos.temperatura.toFixed(1)} °C`;
            document.querySelector('.em-azul .sensor-value').textContent = `${datos.humedad.toFixed(0)} %`;
            document.querySelector('.em-gris .sensor-value').innerHTML = `M4: ${datos.mq4} | M135: ${datos.mq135} <small>ppm</small>`;

            // Variables de entorno de los sensores
            const t = datos.temperatura;
            const h = datos.humedad;
            const m135 = datos.mq135;
            const m4 = datos.mq4;

            // 3. PRIMER PASO: DETERMINAR EN QUÉ FASE ESTÁ EL COMPOST (Motor de Coincidencias)
            let puntosMesofila = 0, puntosTermofila = 0, puntosEnfriamiento = 0, puntosMaduracion = 0;

            // Evaluación Mesófila
            if (t >= 20 && t <= 45) puntosMesofila += 2;
            if (h >= 40 && h <= 65) puntosMesofila += 1;
            if (m135 >= 150 && m135 <= 350) puntosMesofila += 1;
            if (m4 < 150) puntosMesofila += 1;

            // Evaluación Termófila
            if (t >= 40 && t <= 70) puntosTermofila += 2;
            if (h >= 40 && h <= 65) puntosTermofila += 1;
            if (m135 > 350) puntosTermofila += 1;
            if (m4 < 150) puntosTermofila += 1;

            // Evaluación Enfriamiento
            if (t >= 35 && t <= 45) puntosEnfriamiento += 2;
            if (h >= 35 && h <= 60) puntosEnfriamiento += 1;
            if (m135 >= 150 && m135 <= 350) puntosEnfriamiento += 1;
            if (m4 < 150) puntosEnfriamiento += 1;

            // Evaluación Maduración
            if (t >= 15 && t <= 35) puntosMaduracion += 2;
            if (h >= 25 && h <= 45) puntosMaduracion += 1;
            if (m135 < 150) puntosMaduracion += 1;
            if (m4 < 150) puntosMaduracion += 1;

            // Identificar la fase activa
            let maxPuntos = Math.max(puntosMesofila, puntosTermofila, puntosEnfriamiento, puntosMaduracion);
            let faseDetectada = "mesofila";
            if (maxPuntos === puntosTermofila) faseDetectada = "termofila";
            else if (maxPuntos === puntosEnfriamiento) faseDetectada = "enfriamiento";
            else if (maxPuntos === puntosMaduracion) faseDetectada = "maduracion";

            // 4. SEGUNDO PASO: CONTAR CUÁNTOS SENSORES NO ENCAJAN EN LA FASE DETECTADA
            let sensoresFueraDeRango = 0;

            if (faseDetectada === "mesofila") {
                if (!(t >= 25 && t <= 45)) sensoresFueraDeRango++;
                if (!(h >= 45 && h <= 60)) sensoresFueraDeRango++;
                if (!(m135 >= 150 && m135 <= 350)) sensoresFueraDeRango++;
                if (!(m4 < 150)) sensoresFueraDeRango++;
            } 
            else if (faseDetectada === "termofila") {
                if (!(t >= 45 && t <= 65)) sensoresFueraDeRango++;
                if (!(h >= 45 && h <= 60)) sensoresFueraDeRango++;
                if (!(m135 > 350)) sensoresFueraDeRango++;
                if (!(m4 < 150)) sensoresFueraDeRango++;
            } 
            else if (faseDetectada === "enfriamiento") {
                if (!(t >= 40 && t <= 45)) sensoresFueraDeRango++;
                if (!(h >= 40 && h <= 55)) sensoresFueraDeRango++;
                if (!(m135 >= 150 && m135 <= 350)) sensoresFueraDeRango++;
                if (!(m4 < 150)) sensoresFueraDeRango++;
            } 
            else if (faseDetectada === "maduracion") {
                if (!(Math.abs(t - 25.0) <= 5)) sensoresFueraDeRango++; // ±5°C de la ambiente (asumiendo 25°C)
                if (!(h >= 30 && h <= 40)) sensoresFueraDeRango++;
                if (!(m135 < 150)) sensoresFueraDeRango++;
                if (!(m4 < 150)) sensoresFueraDeRango++;
            }

            // 5. TERCER PASO: ASIGNAR EL ESTADO EN BASE A LOS ERRORES
            if (sensoresFueraDeRango === 0) {
                badge.textContent = " Óptimo";
                badge.style.backgroundColor = "#38a169";
                desc.textContent = `Los 4 sensores están estables. El sistema corre perfectamente en Fase ${faseDetectada.toUpperCase()}.`;
            } 
            else if (sensoresFueraDeRango === 1) {
                badge.textContent = "Advertencia";
                badge.style.backgroundColor = "#dd6b20";
                desc.textContent = `¡Cuidado! 1 parámetro se desvió de las condiciones ideales de la Fase ${faseDetectada.toUpperCase()}.`;
            } 
            else {
                badge.textContent = " Crítico";
                badge.style.backgroundColor = "#e53e3e";
                desc.textContent = `¡Alerta! ${sensoresFueraDeRango} sensores no coinciden con la Fase ${faseDetectada.toUpperCase()}. Requiere intervención inmediata.`;
            }
        })
        .catch(error => {
            console.error("Error conectando con los sensores Wi-Fi:", error);
            
            // Si el ESP32 se desconecta
            if (txtStatus) {
                txtStatus.textContent = "Desconectado";
                txtStatus.style.color = "#e53e3e";
            }
            if (badge) {
                badge.textContent = "⏳ Desconectado";
                badge.style.backgroundColor = "#718096";
            }
            if (desc) desc.textContent = "No se pueden calcular restricciones. Verifica el enlace Wi-Fi del dispositivo.";
        });
}

// Inicializadores
consultarSensoresArduino();
setInterval(consultarSensoresArduino, 10000);