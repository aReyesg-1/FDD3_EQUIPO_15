// ==========================================================================
// 1. OBTENER DATOS DEL USUARIO LOGUEADO
// ==========================================================================
const emailActivo = localStorage.getItem('usuarioActivo');
const datosUsuarioRaw = localStorage.getItem(emailActivo);

if (datosUsuarioRaw) {
    const datosUsuario = JSON.parse(datosUsuarioRaw);
    
    // Mostramos el nombre (lo que está antes del @gmail.com)
    const nombreUsuario = datosUsuario.gmail.split('@')[0];
    const userDisplay = document.getElementById('user-display');
    if (userDisplay) userDisplay.textContent = nombreUsuario;
    
    // Mostramos el código del compost que registró
    const compostDisplay = document.getElementById('compost-id-display');
    if (compostDisplay) compostDisplay.textContent = `Código: ${datosUsuario.codigo_compost}`;
}

// ==========================================================================
// 2. CONTROL DEL BOTÓN CERRAR SESIÓN
// ==========================================================================
const logoutBtn = document.getElementById('logout-btn');
if (logoutBtn) {
    logoutBtn.addEventListener('click', (e) => {
        e.preventDefault();
        localStorage.removeItem('usuarioActivo'); // Borra la sesión
        window.location.href = "index.html";     // Regresa al login/registro
    });
}

const ARDUINO_IP = "http://10.46.168.228"; 
// ==========================================================================
// 2. CONFIGURACIÓN DE LA GRÁFICA (INTERVALOS DE 5 HORAS)
// ==========================================================================
const ctx = document.getElementById('chartHistorialCincoHoras');
let graficoHistorial = null;

if (ctx) {
    graficoHistorial = new Chart(ctx.getContext('2d'), {
        type: 'line',
        data: {
            labels: ['00:00', '05:00', '10:00', '15:00', '20:00', 'En vivo'],
            datasets: [
                { label: 'Temperatura (°C)', data: [24, 35, 48, 55, 52, 0], borderColor: '#e53e3e', backgroundColor: 'transparent', borderWidth: 2.5, tension: 0.2 },
                { label: 'Humedad (%)', data: [50, 52, 55, 58, 56, 0], borderColor: '#3182ce', backgroundColor: 'transparent', borderWidth: 2.5, tension: 0.2 },
                { label: 'Metano MQ4 (ppm)', data: [80, 110, 210, 240, 190, 0], borderColor: '#718096', backgroundColor: 'transparent', borderWidth: 1.5, tension: 0.2 }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { position: 'top' } }
        }
    });
}

// ==========================================================================
// 3. DETERMINACIÓN DE FASE BASADA EN RESTRICCIONES DE LOS 4 SENSORES
// ==========================================================================
function consultarSensoresMonitoreo() {
    fetch(`${ARDUINO_IP}/datos`)
        .then(response => response.json())
        .then(datos => {
            console.log("Datos recibidos para análisis de fase:", datos);

            const contenedorFase = document.getElementById('compost-fase-texto');
            
            // Definimos rangos numéricos para los estados de gas según tus tablas:
            // Bajo: < 150 ppm | Medio: 150 - 350 ppm | Alto: > 350 ppm
            const t = datos.temperatura;
            const h = datos.humedad;
            const m135 = datos.mq135;
            const m4 = datos.mq4;

            // Variables de coincidencia para cada fase
            let puntosMesofila = 0;
            let puntosTermofila = 0;
            let puntosEnfriamiento = 0;
            let puntosMaduracion = 0;

            // ---- EVALUACIÓN PARA FASE MESÓFILA ----
            if (t >= 20 && t <= 45) puntosMesofila += 2; // Rango óptimo/advertencia
            if (h >= 40 && h <= 65) puntosMesofila += 1;
            if (m135 >= 150 && m135 <= 350) puntosMesofila += 1; // Medio
            if (m4 < 150) puntosMesofila += 1; // Bajo

            // ---- EVALUACIÓN PARA FASE TERMÓFILA ----
            if (t >= 40 && t <= 70) puntosTermofila += 2;
            if (h >= 40 && h <= 65) puntosTermofila += 1;
            if (m135 > 350) puntosTermofila += 1; // Alto
            if (m4 < 150) puntosTermofila += 1; // Bajo

            // ---- EVALUACIÓN PARA FASE ENFRIAMIENTO ----
            if (t >= 35 && t <= 45) puntosEnfriamiento += 2;
            if (h >= 35 && h <= 60) puntosEnfriamiento += 1;
            if (m135 >= 150 && m135 <= 350) puntosEnfriamiento += 1; // Medio
            if (m4 < 150) puntosEnfriamiento += 1; // Bajo

            // ---- EVALUACIÓN PARA FASE MADURACIÓN ----
            if (t >= 15 && t <= 35) puntosMaduracion += 2; // Cercano a temp ambiente (aprox 25°C)
            if (h >= 25 && h <= 45) puntosMaduracion += 1;
            if (m135 < 150) puntosMaduracion += 1; // Bajo
            if (m4 < 150) puntosMaduracion += 1; // Bajo

            // Determinamos cuál fase obtuvo el mayor puntaje de coincidencia colectiva
            let maxPuntos = Math.max(puntosMesofila, puntosTermofila, puntosEnfriamiento, puntosMaduracion);
            let faseFinal = "Determinando estado...";

            if (maxPuntos === puntosTermofila) {
                faseFinal = " Estado: Fase Termófila";
            } else if (maxPuntos === puntosMesofila) {
                faseFinal = " Estado: Fase Mesófila";
            } else if (maxPuntos === puntosEnfriamiento) {
                faseFinal = "Estado: Fase de Enfriamiento";
            } else if (maxPuntos === puntosMaduracion) {
                faseFinal = " Estado: Fase de Maduración";
            }

            // Renderizar el string limpio en el contenedor HTML
            if (contenedorFase) {
                contenedorFase.textContent = faseFinal;
            }

            // Actualizar gráfica en la última posición
            if (graficoHistorial) {
                graficoHistorial.data.datasets[0].data[5] = t;
                graficoHistorial.data.datasets[1].data[5] = h;
                graficoHistorial.data.datasets[2].data[5] = m4;
                graficoHistorial.update();
            }
        })
        .catch(error => {
            console.error("Error en módulo de monitoreo:", error);
            // ================================================================
            // CAMBIO AUTOMÁTICO A DESCONECTADO SI SE PIERDE EL ENLACE WI-FI
            // ================================================================
            if (txtStatus) {
                txtStatus.textContent = "Desconectado";
                txtStatus.style.color = "#e53e3e"; // Rojo alerta
            }

            const contenedorFase = document.getElementById('compost-fase-texto');
            if (contenedorFase) contenedorFase.textContent = "Dispositivo fuera de línea";
        });
}

// Inicializar procesos cada 10 segundos
consultarSensoresMonitoreo();
setInterval(consultarSensoresMonitoreo, 10000);